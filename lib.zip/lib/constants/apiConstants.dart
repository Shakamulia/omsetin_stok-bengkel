class ApiConstants {
  // static const String baseUrl = "http://10.0.2.2:3000";
  // static const String baseUrl = "https://smiling-squid-especially.ngrok-free.app";
  static const String baseUrl = "https://www.aeratek.id";
  // static const String baseUrl = "https://kas-mini-api-104d450d56ee.herokuapp.com";

  
  static const String login = "$baseUrl/";
}