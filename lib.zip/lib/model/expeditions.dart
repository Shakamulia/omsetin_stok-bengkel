class Expeditions {
  final String expedition;

  Expeditions({required this.expedition});
}


List<Expeditions> itemExpedition = [
  Expeditions(expedition: "JNE"),
  Expeditions(expedition: "J&T Express"),
  Expeditions(expedition: "GoSend"),
  Expeditions(expedition: "Wahana"),
  Expeditions(expedition: "Indah Logistik"),
  Expeditions(expedition: "Pandu Logistik"),
  Expeditions(expedition: "POS Indonesia"),
  Expeditions(expedition: "TIKI"),
  Expeditions(expedition: "Shopee Express"),
  Expeditions(expedition: "Ninja Express"),
  Expeditions(expedition: "First Logistik"),
  Expeditions(expedition: "Pahala Express"),
  Expeditions(expedition: "Ninja Express"),
  Expeditions(expedition: "Grab Express"),
];