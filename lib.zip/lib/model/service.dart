// lib/model/service.dart
class Service {
  final int? id;
  final String name;
  final double price;
  final String dateAdded;

  Service({
    this.id,
    required this.name,
    required this.price,
    required this.dateAdded,
  });

  factory Service.fromMap(Map<String, dynamic> map) {
    return Service(
      id: map['id'],
      name: map['name'],
      price: (map['price'] as num).toDouble(),
      dateAdded: map['dateAdded'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name': name,
      'price': price,
      'dateAdded': dateAdded,
    };
  }
}
