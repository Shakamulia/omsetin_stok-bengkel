import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:intl/intl.dart';
import 'package:omsetin_stok/model/transaction.dart';
import 'package:omsetin_stok/services/database_service.dart';
import 'package:omsetin_stok/utils/colors.dart';
import 'package:omsetin_stok/view/widget/formatter/Rupiah.dart';

class RiwayatTransaksiList extends StatefulWidget {
  final DateTime date;
  const RiwayatTransaksiList({super.key, required this.date});

  @override
  State<RiwayatTransaksiList> createState() => _RiwayatTransaksiListState();
}

class _RiwayatTransaksiListState extends State<RiwayatTransaksiList> {
  DatabaseService db = DatabaseService.instance;
  List<TransactionData> transactionData = [];

  @override
  void initState() {
    super.initState();
    getTransaction();
  }

  void getTransaction() async {
    List<TransactionData> allTransactions = await db.getTransaction();

    final selectedDate = widget.date;

    final filteredTransactions = allTransactions.where((transaction) {
      try {
        String dateStr = transaction.transactionDate.split(', ')[1];
        DateTime transactionDate =
            DateFormat("dd/MM/yyyy HH:mm").parse(dateStr).toLocal();

        return transactionDate.year == selectedDate.year &&
            transactionDate.month == selectedDate.month &&
            transactionDate.day == selectedDate.day;
      } catch (e) {
        print("Error parsing transaction date: ${transaction.transactionDate}");
        return false;
      }
    }).toList();

    setState(() {
      transactionData = filteredTransactions;
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemCount: transactionData.length,
      itemBuilder: (context, index) {
        final statusColorMap = {
          "Selesai": greenColor,
          "Belum Lunas": yellowColor,
          "Belum Dibayar": redColor,
          "Dibatalkan": greyColor,
        };

        final statusColor =
            statusColorMap[transactionData[index].transactionStatus] ??
                secondaryColor;
        return Padding(
          padding: EdgeInsets.symmetric(vertical: 10),
          child: Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                    color: statusColor,
                    borderRadius: BorderRadius.circular(30)),
                child: Center(child: Icon(Icons.receipt_long_rounded)),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Antrian ${transactionData[index].transactionQueueNumber}',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    Text(
                      transactionData[index].transactionDate.toString(),
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    CurrencyFormat.convertToIdr(
                        transactionData[index].transactionTotal, 2),
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
