// lib/view/page/service/add_service_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:omsetin_stok/services/database_service.dart';
import 'package:omsetin_stok/utils/failedAlert.dart';
import 'package:omsetin_stok/utils/successAlert.dart';
import 'package:omsetin_stok/utils/colors.dart';
import 'package:omsetin_stok/view/widget/custom_textfield.dart';
import 'package:gap/gap.dart';
import 'package:omsetin_stok/utils/responsif/fsize.dart';
import 'package:omsetin_stok/view/widget/modals.dart';

class AddServicePage extends StatefulWidget {
  const AddServicePage({super.key});

  @override
  State<AddServicePage> createState() => _AddServicePageState();
}

class _AddServicePageState extends State<AddServicePage> {
  final _nameController = TextEditingController();
  final _priceController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final _databaseService = databaseService;
  final _currencyFormatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  Future<void> _saveService() async {
    if (!_formKey.currentState!.validate()) return;

    final name = _nameController.text.trim();
    final priceText = _priceController.text.replaceAll(RegExp(r'[^0-9]'), '');
    final price = double.tryParse(priceText);

    if (price == null) {
      showFailedAlert(context, message: "Harga harus berupa angka!");
      return;
    }

    final existing = await _databaseService.getServices();
    if (existing.any((s) => s.name.toLowerCase() == name.toLowerCase())) {
      showFailedAlert(context, message: "Layanan sudah ada!");
      return;
    }

    try {
      await _databaseService.addService(
        name,
        price,
        DateTime.now().toIso8601String(),
      );
      showSuccessAlert(context, "Layanan berhasil ditambahkan!");
      Navigator.pop(context, true);
    } catch (e) {
      showFailedAlert(context, message: "Gagal menambahkan layanan: $e");
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final font = GoogleFonts.poppins();
    return Scaffold(
      appBar: AppBar(
        title: Text('Tambah Layanan', style: font.copyWith(fontSize: Fsize(context).subtitle)),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              CustomTextField(
                controller: _nameController,
                label: 'Nama Layanan',
                hintText: 'Contoh: Ganti Oli',
                validator: (val) => val == null || val.trim().isEmpty ? 'Wajib diisi' : null,
              ),
              const Gap(16),
              TextFormField(
                controller: _priceController,
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  CurrencyTextInputFormatter(locale: 'id', symbol: 'Rp ')
                ],
                decoration: const InputDecoration(
                  labelText: 'Harga',
                  hintText: 'Contoh: 100000',
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val == null || val.trim().isEmpty ? 'Wajib diisi' : null,
              ),
              const Gap(24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    textStyle: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  onPressed: _saveService,
                  child: const Text('SIMPAN'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
